
package app;


public class MateriaPrima extends Produto {
    
    private String PlacaLogica;
    private String Bateria;
    private String Tela;

    public String getPlacaLogica() {
        return PlacaLogica;
    }

    public void setPlacaLogica(String PlacaLogica) {
        this.PlacaLogica = PlacaLogica;
    }

    public String getBateria() {
        return Bateria;
    }

    public void setBateria(String Bateria) {
        this.Bateria = Bateria;
    }

    public String getTela() {
        return Tela;
    }

    public void setTela(String Tela) {
        this.Tela = Tela;
    }
    
    
    
}
