
package app;


public class ProdutoAcabado extends Produto {
    
    private String Fone;
    private String Carregador;
    private String Cabo;

    public String getFone() {
        return Fone;
    }

    public void setFone(String Fone) {
        this.Fone = Fone;
    }

    public String getCarregador() {
        return Carregador;
    }

    public void setCarregador(String Carregador) {
        this.Carregador = Carregador;
    }

    public String getCabo() {
        return Cabo;
    }

    public void setCabo(String Cabo) {
        this.Cabo = Cabo;
    }
    
    
    
}
