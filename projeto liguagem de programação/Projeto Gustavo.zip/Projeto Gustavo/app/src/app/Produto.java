
package app;


public class Produto {
    
    private String NumeroSerie;
    private String NumeroModelo;

    public String getNumeroSerie() {
        return NumeroSerie;
    }

    public void setNumeroSerie(String NumeroSerie) {
        this.NumeroSerie = NumeroSerie;
    }

    public String getNumeroModelo() {
        return NumeroModelo;
    }

    public void setNumeroModelo(String NumeroModelo) {
        this.NumeroModelo = NumeroModelo;
    }
    
    
    
}
